/* ================================================================
   TWA AERO — interactions
   ================================================================ */
document.addEventListener('DOMContentLoaded', () => {

  /* ---------- Mobile nav toggle ---------- */
  const navToggle = document.getElementById('nav-toggle');
  const primaryNav = document.getElementById('primary-nav');

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = primaryNav.classList.toggle('open');
      navToggle.classList.toggle('open', isOpen);
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });

    primaryNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        primaryNav.classList.remove('open');
        navToggle.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  /* ---------- Active nav link on scroll ---------- */
  const navLinks = document.querySelectorAll('[data-nav]');
  const sections = [...navLinks]
    .map(link => document.querySelector(link.getAttribute('href')))
    .filter(Boolean);

  const setActiveLink = () => {
    let current = sections[0];
    const offset = window.innerHeight * 0.35;
    sections.forEach(sec => {
      if (sec.getBoundingClientRect().top - offset <= 0) current = sec;
    });
    navLinks.forEach(link => {
      link.classList.toggle('active', link.getAttribute('href') === `#${current.id}`);
    });
  };

  /* ---------- Reveal on scroll ---------- */
  const revealEls = document.querySelectorAll('[data-reveal]');
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15, rootMargin: '0px 0px -60px 0px' });

  revealEls.forEach((el, i) => {
    el.style.transitionDelay = `${(i % 4) * 0.08}s`;
    revealObserver.observe(el);
  });

  /* ---------- Animated stat counters ---------- */
  const counters = document.querySelectorAll('[data-count]');
  const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const target = parseInt(el.dataset.count, 10);
      const duration = 1400;
      const start = performance.now();

      const tick = (now) => {
        const progress = Math.min((now - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        el.textContent = Math.round(eased * target);
        if (progress < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      counterObserver.unobserve(el);
    });
  }, { threshold: 0.6 });

  counters.forEach(el => counterObserver.observe(el));

  /* ---------- Flight-path scroll progress (desktop) ---------- */
  const routeLineFill = document.getElementById('route-line-fill');
  const routePath = document.getElementById('route-path');
  const routePlane = document.querySelector('.route-plane');

  let routeLength = 0;
  if (routePath) {
    routeLength = routePath.getTotalLength();
    if (routeLineFill) {
      routeLineFill.style.strokeDasharray = `${routeLength}`;
      routeLineFill.style.strokeDashoffset = `${routeLength}`;
    }
  }

  /* ---------- Mobile top progress ---------- */
  const topTrack = document.querySelector('.top-progress-track');
  const topPlane = document.querySelector('.top-progress-plane');

  const updateProgress = () => {
    const doc = document.documentElement;
    const scrollTop = window.scrollY || doc.scrollTop;
    const max = (doc.scrollHeight - doc.clientHeight) || 1;
    const progress = Math.min(Math.max(scrollTop / max, 0), 1);

    if (routePath && routeLineFill && routePlane) {
      routeLineFill.style.strokeDashoffset = `${routeLength * (1 - progress)}`;
      const point = routePath.getPointAtLength(routeLength * progress);
      const ahead = routePath.getPointAtLength(Math.min(routeLength, routeLength * progress + 1));
      const angle = Math.atan2(ahead.y - point.y, ahead.x - point.x) * (180 / Math.PI) + 90;
      routePlane.style.left = `${(point.x / 60) * 100}%`;
      routePlane.style.top = `${(point.y / 1200) * 100}%`;
      routePlane.style.transform = `translate(-50%,-50%) rotate(${angle}deg)`;
    }

    if (topTrack && topPlane) {
      topTrack.style.width = `${progress * 100}%`;
      topPlane.style.left = `${progress * 100}%`;
    }

    setActiveLink();
  };

  let ticking = false;
  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(() => { updateProgress(); ticking = false; });
      ticking = true;
    }
  });
  window.addEventListener('resize', () => {
    if (routePath) routeLength = routePath.getTotalLength();
    updateProgress();
  });
  updateProgress();

  /* ---------- Hero blob parallax (pointer follow) ---------- */
  const heroVisual = document.querySelector('.hero-visual');
  const heroBlob = document.querySelector('.hero-blob');
  const heroJet = document.querySelector('.hero-jet');

  if (heroVisual && window.matchMedia('(pointer: fine)').matches) {
    heroVisual.addEventListener('mousemove', (e) => {
      const rect = heroVisual.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width - 0.5;
      const y = (e.clientY - rect.top) / rect.height - 0.5;
      if (heroBlob) heroBlob.style.transform = `translate(${x * 24}px, ${y * 24}px)`;
      if (heroJet) heroJet.style.transform = `translate(${x * -14}px, ${y * -10}px)`;
    });
    heroVisual.addEventListener('mouseleave', () => {
      if (heroBlob) heroBlob.style.transform = '';
      if (heroJet) heroJet.style.transform = '';
    });
  }

  /* ---------- Quote form ---------- */
  const form = document.getElementById('quote-form');
  const formNote = document.getElementById('form-note');

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!form.checkValidity()) return;

      const submitBtn = form.querySelector('button[type="submit"] span');
      const original = submitBtn ? submitBtn.textContent : '';
      if (submitBtn) submitBtn.textContent = 'Sending…';

      try {
        const response = await fetch('/', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams(new FormData(form)).toString(),
        });

        if (submitBtn) submitBtn.textContent = original;

        if (response.ok) {
          if (formNote) {
            formNote.textContent = 'Thanks — your request has been noted. Our team will reach out shortly.';
            formNote.classList.add('success');
          }
          form.reset();
        } else {
          if (formNote) {
            formNote.textContent = 'Something went wrong. Please email us directly at sales@twaaero.com.';
            formNote.classList.add('error');
          }
        }
      } catch {
        if (submitBtn) submitBtn.textContent = original;
        if (formNote) {
          formNote.textContent = 'Something went wrong. Please email us directly at sales@twaaero.com.';
          formNote.classList.add('error');
        }
      }
    });
  }
});
